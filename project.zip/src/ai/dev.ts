import { config } from 'dotenv';
config();

import '@/ai/flows/generate-panel-summary.ts';